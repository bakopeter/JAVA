import java.util.Random;
import java.io.File;
import java.util.Scanner;


void main() {
    IO.println("3. feladat");

    int[] haviEladasok = new int[12];

    File file = new File("eladasok.txt");
    try(Scanner myReader = new Scanner(file)) {
        while (myReader.hasNextLine()) {
            String sor = myReader.nextLine().trim();
            if (sor != "") {
                String[] eladasok = sor.split(" ");
                for (int i = 0; i < haviEladasok.length; i++) {
                    haviEladasok[i] += Integer.parseInt(eladasok[i+1]);
                }
            }
        }
    } catch (Exception e) {
        IO.println("A fájl beolvasása nem sikerült!");
    }

    String[] honapok = {
            "Január", "Február", "Március", "Április", "Május", "Június",
            "Július", "Augusztus", "Szeptember", "Október", "November", "December"
    };

    IO.println("Notebookok eladásai havi bontásban:");
    for (var i=0; i<haviEladasok.length; i++) IO.println(honapok[i] + ": " + haviEladasok[i] + " db");
}
