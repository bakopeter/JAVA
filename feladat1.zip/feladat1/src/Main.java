import java.io.File;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        // ====================================================
        // 1. FELADAT
        // ====================================================
        IO.println("1. feladat:");

        int[] elemek = new int[10];
        Random rnd = new Random();

        for (int i = 0; i < elemek.length; i++) {
            elemek[i] = rnd.nextInt(10);
        }

        IO.print("A lista tartalma: [");
        int i = 1;
        IO.print(elemek[0]);
        do {
            IO.print(", ");
            IO.print(elemek[i]);
            i++;
        } while (i < elemek.length);
        IO.println("]");

        int kisebb5 = 0;
        int nagyobb5 = 0;
        for (int j = 0; j < elemek.length; j++) {
            if (elemek[j] < 5) {
                kisebb5 += elemek[j];
            } else if (elemek[j] > 5) {
                nagyobb5 += elemek[j];
            }
        }

        IO.println("5-nél kisebb elemek összege: " + kisebb5);
        IO.println("5-nél nagyobb elemek összege: " + nagyobb5);


        // ====================================================
        // 2. FELADAT
        // ====================================================
        IO.println("\n2. feladat:");

        // a) Páratlan elemek megszámlálása
        int paratlanCount = 0;
        for (int j = 0; j < elemek.length; j++) {
            if (elemek[j] % 2 != 0) {
                paratlanCount++;
            }
        }

        IO.println("A listában lévő páratlan elemek száma: " + paratlanCount + " db");
        if (paratlanCount < 4) {
            IO.println("Igaz az állítás!");
        } else {
            IO.println("Nem igaz az állítás!");
        }

        // b) Legnagyobb elem keresése és előfordulásának vizsgálata
        int maxElem = elemek[0];
        for (int j = 1; j < elemek.length; j++) {
            if (elemek[j] > maxElem) {
                maxElem = elemek[j];
            }
        }

        // Előfordulás a lista első felében (az első 5 elem között)
        int elsoFelCount = 0;
        for (int j = 0; j < 5; j++) {
            if (elemek[j] == maxElem) {
                elsoFelCount++;
            }
        }

        // Előfordulás a lista második felében
        int masodikFelCount = 0;
        for (int j = 5; j < 10; j++) {
            if (elemek[j] == maxElem) {
                masodikFelCount++;
            }
        }

        IO.println("A listában lévő legnagyobb elem: " + maxElem);
        IO.println("A legnagyobb elem előfordulása a lista első felében: " + elsoFelCount + " db");
        IO.println("A legnagyobb elem előfordulása a lista második felében: " + masodikFelCount + " db");

        if (elsoFelCount > masodikFelCount) {
            IO.println("Igaz az állítás!");
        } else {
            IO.println("Nem igaz az állítás!");
        }


        // ====================================================
        // 3. FELADAT
        // ====================================================
        IO.println("\n3. feladat:");
        
        IO.println("Notebookok eladásai havi bontásban:");
        
        int[] haviEladasok = new int[12];

        // Fájlbeolvasás és havonkénti összegezése
        try (Scanner scanner = new Scanner(new File("eladasok.txt"))) {
            while (scanner.hasNextLine()) {
                String sor = scanner.nextLine().trim();
                if (!sor.isEmpty()) {
                    String[] reszek = sor.split("\\s+");
                    // Az 0. elem a gyártó neve, az 1..12. elemek a havi adatok
                    for (int m = 0; m < 12; m++) {
                        haviEladasok[m] += Integer.parseInt(reszek[m + 1]);
                    }
                }
            }
        } catch (Exception e) {
            IO.println("A fájl beolvasása nem sikerült!");
        }

        String[] honapok = {
            "Január", "Február", "Március", "Április", "Május", "Június",
            "Július", "Augusztus", "Szeptember", "Október", "November", "December"
        };

        // Havi eladások kiírása
        for (int m = 0; m < 12; m++) {
            IO.println(honapok[m] + ": " + haviEladasok[m] + " db");
        }
    }
}