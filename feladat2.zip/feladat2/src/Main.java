//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
    // to see how IntelliJ IDEA suggests fixing it.
    IO.println(String.format("1. feladat"));

    int[] elemek = new int[10];
    Random rnd = new Random();

    for (int i = 1; i < elemek.length; i++) {
        elemek[i] = rnd.nextInt(10);
    }

    IO.print("A lista tartalma: [");
    for (int i = 0; i < elemek.length; i++) {
        if (i < elemek.length-1) {
            IO.print(elemek[i] + ", ");
        } else {
            IO.println(elemek[i] + "]");
        }
    }

    IO.println(String.format("\n2. feladat"));
    IO.println("a) Igaz, hogy a listában 4-nél kevesebb páratlan szám szerepel?");

    int paratlanDb = 0;
    for (int i = 0; i < elemek.length; i++) {
        if (elemek[i] % 2 != 0) paratlanDb++;
    }

    IO.println("A listában lévő páratlan elemek száma: " + paratlanDb + "db");
    if (paratlanDb < 4) {
        IO.println("Igaz az állítás!");
    } else IO.println("Nem igaz az állítás!");

    IO.println("\nb) Igaz, hogy a listában lévő legnagyobb elem többször fordul elő a lista első felében " +
            "(az első 5 elem között), mint a második felében? ");

    int maxElem = elemek[0];
    for (int i = 1; i < elemek.length; i++) {
        if (elemek[i] > maxElem) maxElem = elemek[i];
    }
    IO.println("A listában lévő legnagyobb elem: " + maxElem);

    int elso5 = 0;
    int masodik5 = 0;
    for (int i = 0; i < elemek.length; i++) {
        if (elemek[i] == maxElem) {
            if (i < 5) elso5++;
            else masodik5++;
        }
    }
    IO.println("A legnagyobb elem előfordulása a lista első felében: " + elso5 + "db");
    IO.println("A legnagyobb elem előfordulása a lista második felében: " + masodik5 + "db");

    if (elso5 > masodik5) IO.println("Igaz az állítás!");
    else IO.println("Nem igaz az állítás!");
}
